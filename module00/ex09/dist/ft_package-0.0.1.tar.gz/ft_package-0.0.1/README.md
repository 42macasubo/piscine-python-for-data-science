My first Python package
