def say_bye() -> None:
    """say bye"""
    print("Bye!")
