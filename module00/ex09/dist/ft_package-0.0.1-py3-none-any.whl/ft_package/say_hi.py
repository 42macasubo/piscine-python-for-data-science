def say_hi() -> None:
    """say hi"""
    print("Hi!")
